# puprisa/controllers/curve_controller.py
"""Qt controller for curve-related user actions."""
from PySide6.QtCore import QObject, Qt
from PySide6.QtWidgets import QFileDialog, QMessageBox, QWidget, QDialog

from puprisa.model.stack_manager import StackManager
from puprisa.ui.dialogs.normalize_curve import NormalizeOptionDialog
from puprisa.ui.dialogs.spectrum import SpectrumDialog
from puprisa.utils.curve_plot_utils import draw_roi_curves
from shiboken6 import isValid
import matplotlib.pyplot as plt

from puprisa.model.curve_manager import CurveManager
from puprisa.core.fit import fit_curve
from puprisa.model.entities import CurveItem
from puprisa.ui.dialogs.curve_fit import CurveFitDialog

class CurveController(QObject):
    """Handle export / standalone view for curve data.

    The controller is stateless with respect to view options; the window
    passes the current space and normalization flag when invoking actions.
    """

    def __init__(self, curve_manager: CurveManager, stack_manager: StackManager, parent_widget: QWidget | None):
        super().__init__()
        self._curve_manager = curve_manager
        self._stack_manager = stack_manager
        self._parent = parent_widget
        self._fit_dialog: CurveFitDialog | None = None
        self._spectrum_dialog: SpectrumDialog | None = None

    # ------------------------------------------------------------------
    # Normalize Curve
    # ------------------------------------------------------------------
    def open_normalize_option_dialog(self) -> None:
        current_item = self._stack_manager.get_current_item()
        if current_item is None:
            QMessageBox.warning(self._parent, "Normalize Curve", "Please select a stack first.")
            return
        pps = current_item.pps

        dialog = NormalizeOptionDialog(
            axis_values=pps.get_axis_values(),
            axis_unit=pps.get_axis_unit(),
            axis_symbol="t" if pps.axis_type == "time" else "z",
            normalize_option=self._curve_manager.normalize_option,
            parent=self._parent,
        )

        if dialog.exec() == QDialog.DialogCode.Accepted:
            self._curve_manager.set_normalize_option(dialog.get_normalize_option())

    # ------------------------------------------------------------------
    # Export Curve
    # ------------------------------------------------------------------
    def export_curve_dialog(self, space: str, normalize: bool) -> bool:
        curves = self._curve_manager.compute_curves(space=space, normalize=normalize)
        if not curves:
            QMessageBox.warning(self._parent, "Export Curves", "No curve data available.")
            return False

        path, _ = QFileDialog.getSaveFileName(self._parent, "Export Curve Data", "curves.csv", "CSV Files (*.csv);;All Files (*)")
        if not path:
            return False

        try:
            self._curve_manager.export_to_csv(path, curves)
            return True
        except (OSError, ValueError) as exc:
            QMessageBox.critical(self._parent, "Export Curves", f"Export failed:\n{exc}")
            return False

    # ------------------------------------------------------------------
    # View Curve
    # ------------------------------------------------------------------
    def view_standalone(self, space: str, normalize: bool) -> None:
        curves = self._curve_manager.compute_curves(space=space, normalize=normalize)
        if not curves:
            QMessageBox.warning(self._parent, "View Curves", "No curve data available.")
            return
        fig, ax = plt.subplots(figsize=(4, 3), layout="constrained")
        current_item = self._stack_manager.get_current_item()
        if current_item is not None:
            pps = current_item.pps
            xlabel = f"{pps.get_axis_label()} ({pps.get_axis_unit()})"
        else:
            xlabel = "Time delay (ps)"
        ylabel = "Normalized signal (a.u.)" if normalize else "Average signal (a.u.)"
        title = "ROI Averaged Curves"

        draw_roi_curves(ax, curves, xlabel=xlabel, ylabel=ylabel, title=title)
        fig.show()

    # ------------------------------------------------------------------
    # Curve Fitting
    # ------------------------------------------------------------------
    def open_fit_dialog(self, space: str, normalize: bool) -> None:
        curves = self._curve_manager.compute_curves(space=space, normalize=normalize)
        if not curves:
            QMessageBox.warning(self._parent, "Curve Fitting", "No visible ROIs available.")
            return
        if self._fit_dialog is not None and isValid(self._fit_dialog):
            self._fit_dialog.close()
        self._fit_dialog = None
        dialog = CurveFitDialog(self._parent)
        dialog.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, True)
        dialog.fitRequested.connect(
            lambda d = dialog: self._handle_fitRequested(d, space, normalize)
        )
        dialog.show()
        self._fit_dialog = dialog

    def _handle_fitRequested(self, dialog: CurveFitDialog, space: str, normalize: bool) -> None:
        curves = self._curve_manager.compute_curves(space=space, normalize=normalize)
        if not curves:
            QMessageBox.warning(self._parent, "Curve Fitting", "No visible ROIs available. Please check ROI visibility.")
            return

        options = dialog.get_fit_options()
        fig, ax = plt.subplots(figsize=(8, 6), layout="constrained")
        result_text_lines = []
        success_count = 0

        for curve in curves:
            result = fit_curve(curve.x, curve.y, options)
            if not result.success:
                result_text_lines.append(f"{curve.label}: FAILED ({result.message})")
                continue

            ax.plot(result.x, result.y, "o", markersize=3, label=f"{curve.label} (data)", color=curve.color)
            ax.plot(result.x_fit, result.y_fit, "-", linewidth=1.5, label=f"{curve.label} (fit)", color=curve.color, alpha=0.85)

            param_str = ", ".join(
                f"{name}={value:.4f}±{result.perr.get(name, float('nan')):.4f}"
                for name, value in result.popt.items()
            )
            result_text_lines.append(f"{curve.label}: {param_str}")
            success_count += 1

        if success_count == 0:
            QMessageBox.critical(self._parent, "Curve Fitting", "All fits failed.")
            return

        current_item = self._stack_manager.get_current_item()
        if current_item is not None:
            pps = current_item.pps
            xlabel = f"{pps.get_axis_label()} ({pps.get_axis_unit()})"
        else:
            xlabel = "Time delay (ps)"

        ax.set_xlabel(xlabel)
        ax.set_ylabel("Normalized signal (a.u.)" if normalize else "Average signal (a.u.)")
        ax.set_title("Curve Fitting Results")
        ax.grid(True, alpha=0.4)
        ax.legend(fontsize=8, loc="best")
        fig.show()
        dialog.set_result_text("\n".join(result_text_lines))

    # ------------------------------------------------------------------
    # Curve Spectrum Analysis
    # ------------------------------------------------------------------
    def open_spectrum_dialog(self, space: str = "pixel") -> None:
        dialog = SpectrumDialog(
            self._curve_manager,
            self._stack_manager,
            parent=self._parent,
            space=space,
        )
        dialog.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, True)
        dialog.show()
        self._spectrum_dialog = dialog